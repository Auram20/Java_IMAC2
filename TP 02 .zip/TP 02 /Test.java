
// ================================
// POO JAVA - IMAC 2 - ANIK Myriam
// TP 2 - Exo 02 suite
// Pour (dé)commenter un bloc : Cmd+Shift+/ ou Ctrl + Shift + / 
// ================================

public class Test
{
	public static void main(String[] args)
	{
		// 04.  ' ' pour un caractère. " " pour un string. On peut l'utiliser là car l'espace est considéré comme un caractere. 
		
         var first = args[0];
         var second = args[1];
         var last = args[2];
         System.out.println(first + ' ' + second + ' ' + last);
       
	}
}

// Bytecode : On en déduit 	



// 05. Le bytecode nous permet de déduire qu'utiliser append est plus rapide et opti qu'utiliser l'opérateur +
