// ================================
// POO JAVA - IMAC 2 - ANIK Myriam
// TP 4 - Exo 03
// Pour (dé)commenter un bloc : Cmd+Shift+/ ou Ctrl + Shift + / 
// ================================


import java.util.*;

public class Test   
{  
     public static void main(String[] args) 
	{
        List<String> someList = new ArrayList<String>();
        someList.add("bidule");
        someList.add("machin");
        for (String item : someList) {
            System.out.println(item);
        }

	}
}

