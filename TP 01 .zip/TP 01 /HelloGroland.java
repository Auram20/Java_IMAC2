// ================================
// POO JAVA - IMAC 2 - ANIK Myriam
// TP 1 - Exo 01
// Pour (dé)commenter un bloc : Cmd+Shift+/ ou Ctrl + Shift + / 
// ================================



   public class HelloGroland 
   {
        public static void main(String[] args) 
        {
          System.out.println("Hello Groland");
        }
      }
     