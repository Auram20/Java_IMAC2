enum AppleKind {
    Golden, PinkLady, GrannySmith;
  }

