// ================================
// POO JAVA - IMAC 2 - ANIK Myriam
// TP 8
// Pour (dé)commenter un bloc : Cmd+Shift+/ ou Ctrl + Shift + / 
// ================================



public class Fruit 
{

    int _quantity;
   

// ================ ATTRIBUTS ================


// ================ CONSTRUCTEURS ================

public Fruit() 
    {
    }

// ================ METHODES ================
public int getQuantity() 
    {
		return _quantity;
    }
public void setQuantity(int quantity) 
    {
		this._quantity = quantity;
	}
}

